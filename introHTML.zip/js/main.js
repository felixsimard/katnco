function _(x) {
	return document.getElementById(x);
}
function _class(x) {
	return document.getElementsByClassName(x);
}